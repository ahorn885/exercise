# Handoff: AIDSTATION Brand v0.2 — Differential

## What this is
A **differential handoff** covering only what changed between **Brand System v0.1**
(the previous handoff) and **v0.2**. If you already have v0.1 implemented in the
`exercise` repo, this is the patch.

If you're starting fresh and don't have v0.1 yet, also grab the original handoff
(`design_handoff_aidstation_brand/`) — together they describe the complete system.

> **Brand guide:** `AidStation Brand Guide v2.html`

---

## Summary of changes (v0.1 → v0.2)

| Area | v0.1 | v0.2 |
|---|---|---|
| Logo | Wordmark only (`AID` 800 / `STATION` 400) | Wordmark **+ pictorial mark** (cup with terminal prompt) **+ horizontal lockup** |
| Logo files | None — wordmark was set live in CSS | **24 SVG/PNG exports** in `logo-exports/` (mark, lockup, stacked × 4 modes) |
| Banners | Not in scope | **Two-direction banner system** (Terminal + Topo) across 11 sizes including a new **GitHub repo social preview at 1280 × 640** |
| Colors | unchanged |
| Type | unchanged |
| Voice | unchanged |
| Spacing / radius | unchanged |

Nothing in the v0.1 token set, type scale, voice rules, or layout system has
changed. Don't re-do that work.

---

## 1 · Logo — new mark + lockup

### Concept
The mark is the **aid-station cup** (paper cup silhouette) with a **terminal prompt**
(`>` arrow + caret block) inside. The cup says race-day; the prompt says
built-in-the-terminal. The caret block is the **only** orange element — it's the
brand's signal in miniature.

### Three logo formats — use the right one
| Format | When to use | Asset prefix |
|---|---|---|
| **Mark** (cup glyph alone, square) | Avatar, app icon, favicon, anywhere the wordmark won't fit | `aidstation-mark--*` |
| **Horizontal lockup** (mark + wordmark side-by-side) | Default for nav bars, headers, marketing | `aidstation-lockup--*` |
| **Stacked** (mark above wordmark) | Square/portrait contexts where horizontal lockup is too wide | `aidstation-stacked--*` |
| **Wordmark only** (no mark) | Inline copy, footers, tight UI; minimum 18 px | (CSS-typeset, see v0.1 handoff) |

### Four color modes — every format ships in all four
| Mode | Background | Foreground | Use |
|---|---|---|---|
| `--dark` | `#0E0F11` (Ink) | `#F4F4F2` (Paper) | Default, on dark surfaces |
| `--light` | `#F4F4F2` (Paper) | `#0E0F11` (Ink) | On light surfaces |
| `--transparent-on-dark` | transparent | `#F4F4F2` | Over photography or colored panels (dark bias) |
| `--transparent-on-light` | transparent | `#0E0F11` | Over photography or colored panels (light bias) |

In **every** mode, the caret block remains `#E8893A` (Course Orange).

### File listing — `logo-exports/`
```
aidstation-mark--dark.svg / .png (2x)
aidstation-mark--light.svg / .png (2x)
aidstation-mark--transparent-on-dark.svg / .png (2x)
aidstation-mark--transparent-on-light.svg / .png (2x)

aidstation-lockup--dark.svg / .png (2x)
aidstation-lockup--light.svg / .png (2x)
aidstation-lockup--transparent-on-dark.svg / .png (2x)
aidstation-lockup--transparent-on-light.svg / .png (2x)

aidstation-stacked--dark.svg / .png (2x)
aidstation-stacked--light.svg / .png (2x)
aidstation-stacked--transparent-on-dark.svg / .png (2x)
aidstation-stacked--transparent-on-light.svg / .png (2x)
```

24 files total. **Always use the SVG** in the web app. PNG `@2x` are 256 px / 1440 px wide
fallbacks for non-SVG contexts (email, OG images that need raster).

### Construction (for inline-SVG implementations)
The mark is built on a 100 × 100 viewBox. In `logo-exports/aidstation-mark--dark.svg`
it is scaled `1.92×` and translated `(32, 32)` inside a 256 × 256 frame.

```svg
<!-- cup -->
<path d="M26 30 L74 30 L67 84 Q 50 92, 33 84 Z" fill="none" stroke="#F4F4F2" stroke-width="6" stroke-linejoin="round"/>
<line x1="26" y1="30" x2="74" y2="30" stroke="#F4F4F2" stroke-width="6" stroke-linecap="round"/>
<!-- prompt arrow -->
<path d="M40 54 L48 60 L40 66" stroke="#F4F4F2" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
<!-- caret block (always orange) -->
<rect x="53" y="55" width="9" height="10" fill="#E8893A"/>
```

Stroke widths above are for the 256 px raster. Inline SVG at smaller sizes should
keep the same numeric values — the strokes are part of the mark's visual weight,
they shouldn't visually thin out.

### Clearspace
Reserve a margin equal to **the cap-height of the wordmark** on every side of
the mark or lockup. Don't crowd it with type, photography, or other marks.

### Minimum sizes
- Mark — **16 px** square (favicon)
- Wordmark — **18 px**
- Lockup — **96 px** wide (any narrower, drop to wordmark or to the mark)

### Don't
- Don't recolor the caret block. It's always `#E8893A`.
- Don't set the cup in orange on a non-orange background.
- Don't put the lockup on a busy photo without a darkening overlay (use the
  transparent assets only when the background contrast is sufficient).
- Don't introduce a tagline lockup. The wordmark stands alone.

### React component (drop-in)
```jsx
function AidstationMark({ size = 32, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" aria-label="AIDSTATION">
      <path d="M26 30 L74 30 L67 84 Q 50 92, 33 84 Z" fill="none" stroke={color} strokeWidth="6" strokeLinejoin="round"/>
      <line x1="26" y1="30" x2="74" y2="30" stroke={color} strokeWidth="6" strokeLinecap="round"/>
      <path d="M40 54 L48 60 L40 66" stroke={color} strokeWidth="5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
      <rect x="53" y="55" width="9" height="10" fill="#E8893A"/>
    </svg>
  );
}

function AidstationLockup({ height = 32 }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: height * 0.4 }}>
      <AidstationMark size={height} />
      <span style={{
        fontFamily: 'Inter, system-ui, sans-serif',
        fontSize: height * 0.9,
        letterSpacing: '0.04em',
        lineHeight: 1,
      }}>
        <span style={{ fontWeight: 800 }}>AID</span><span style={{ fontWeight: 400 }}>STATION</span>
      </span>
    </span>
  );
}
```

---

## 2 · Banners — new social/repo system

A two-direction banner system, both rendered live in SVG so they scale and stay editable.

### Direction A — **Terminal**
Dark `--ink` field, monospace shell session showing a `git clone` and an
`aidstation plan today` invocation. Orange highlights on the live numbers.

### Direction B — **Topo**
Dark gradient field, course elevation profile in monospace with a "summit" pin
and code annotations along the curve.

### Sizes shipped (each direction × 11 sizes × {SVG, PNG} = 44 files)

| Platform | File stem | Size |
|---|---|---|
| **GitHub repo social preview** | `github/github-social-preview` | **1280 × 640** ← new in v0.2 |
| X / Twitter header | `twitter/twitter-header` | 1500 × 500 |
| Bluesky banner | `bluesky/bluesky-banner` | 1500 × 500 |
| LinkedIn personal cover | `linkedin/linkedin-personal` | 1584 × 396 |
| LinkedIn company cover | `linkedin/linkedin-company` | 1128 × 191 |
| Facebook page cover | `facebook/facebook-page-cover` | 1640 × 624 |
| Facebook personal cover | `facebook/facebook-personal-cover` | 851 × 315 |
| YouTube channel art | `youtube/youtube-channel-art` | 2560 × 1440 |
| Instagram square | `instagram/instagram-square` | 1080 × 1080 |
| Instagram story | `instagram/instagram-story` | 1080 × 1920 |
| TikTok profile | `tiktok/tiktok-profile` | 1080 × 1080 |

Path pattern:
```
social-banners/{terminal|topo}/{platform}/{file}.{svg|png}
```

### What to wire up in the `exercise` repo

These are **marketing assets**, not in-product UI. Most live outside the codebase
(uploaded to GitHub Settings → Social preview, X profile, LinkedIn page, etc.).
What you actually need to wire up in the repo:

1. **Open Graph image** — pick one banner per page and reference it in `<head>`:
   ```html
   <meta property="og:image" content="https://aidstation.pro/og/github-social-preview.png" />
   <meta property="og:image:width" content="1280" />
   <meta property="og:image:height" content="640" />
   <meta name="twitter:card" content="summary_large_image" />
   <meta name="twitter:image" content="https://aidstation.pro/og/github-social-preview.png" />
   ```
   The Terminal direction reads better at small sizes — recommended for the default OG image.
2. **Favicon set** — generate from `logo-exports/aidstation-mark--light.svg`:
   ```html
   <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
   <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png" />
   <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
   ```
3. **GitHub repo social preview** — upload `social-banners/terminal/github/github-social-preview.png`
   to the repo's Settings → Social preview field. (Not a code change.)

This handoff folder includes only the GitHub banners. The full set lives in the
project under `social-banners/` — copy any you also want to ship as web assets.

---

## 3 · No changes (skip if implementing)
For completeness, here is what is **unchanged** from v0.1. If your v0.1 implementation
is already live, you do not need to revisit:

- Color tokens (Course Orange / Ember / Tape / Ink scale / Paper scale / hairlines)
- Typography stack (Inter + JetBrains Mono) and type scale
- 60 / 30 / 10 color usage rule
- Voice & tone — sounds like / never sounds like
- Spacing scale, 4 px radius standard, 1 px hairline divider system

Refer to the v0.1 handoff README for those.

---

## Files in this bundle
- `README.md` — this differential handoff
- `AidStation Brand Guide v2.html` — updated visual reference (open in a browser)
- `logo-exports/` — all 24 logo files (4 modes × 3 lockup formats × {SVG, 2× PNG})
- `social-banners/{terminal,topo}/github/github-social-preview.{svg,png}` — the new 1280×640 banners

If you also want the banners for X, LinkedIn, Facebook, etc. ask and I'll bundle them.
