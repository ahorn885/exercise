# Handoff: AIDSTATION Brand System (v0.1)

## Overview
This package contains the **AIDSTATION** brand system — colors, typography, logo
treatments, voice, and example applications — to be applied to the existing
`exercise` web app. AIDSTATION is positioned as AI-driven training for the
data-obsessed endurance athlete (Ironman, ultra, adventure race), built by
multi-sport athletes for the endurance community.

The goal of this handoff is for you (Claude Code, working in the `exercise`
repo) to take the design tokens and patterns described here and integrate them
into the existing codebase using its existing conventions (CSS variables,
component library, framework patterns — whatever is already there).

## About the design files
The HTML file in this folder (`AidStation Brand Guide.html`) is a **design
reference** — a static prototype showing the intended look. It is not
production code to copy verbatim. Your task is to **apply the tokens, type
system, and visual rules described in this README** to the `exercise`
codebase using its existing environment (React, Vue, plain CSS, etc.). If the
codebase has no existing styling foundation, set one up using these tokens
in whatever way is idiomatic for the framework in use.

## Fidelity
**High-fidelity.** All colors, type sizes, weights, tracking values, and
spacing are final. Use the exact values listed in the Design Tokens section.

---

## Brand voice (one-liner)
> AI-driven training for the data-obsessed endurance athlete. Built by
> multi-sport athletes, for the endurance community — to prepare you for your
> next Ironman, ultra, or three-day adventure race.

Tone descriptors: **Technical · Calm · In your corner.** Allergic to hype.

---

## Design Tokens

### Colors

All colors are defined in OKLCH with a hex approximation. Prefer OKLCH in CSS
custom properties; use hex for assets / non-CSS contexts.

| Token | Role | OKLCH | Hex |
|---|---|---|---|
| `--orange` | Primary · Signal (Course Orange) | `oklch(0.72 0.18 55)` | `#ED7A2D` |
| `--orange-deep` | Hover / pressed (Ember) | `oklch(0.62 0.18 50)` | `#C75E1F` |
| `--orange-soft` | Tint / notice (Tape) | `oklch(0.86 0.10 60)` | `#F3C896` |
| `--ink` | Foundation dark (Ink) | `oklch(0.16 0.005 250)` | `#1B1D21` |
| `--ink-2` | Surface dark (Ink 80) | `oklch(0.22 0.005 250)` | `#2A2D31` |
| `--ink-3` | Muted dark (Slate) | `oklch(0.32 0.008 250)` | `#444851` |
| `--paper` | Foundation light (Paper) | `oklch(0.98 0.005 80)` | `#FAFAF7` |
| `--paper-2` | — | `oklch(0.95 0.006 80)` | (≈`#F0EDE5`) |
| `--paper-3` | Surface light (Bone) | `oklch(0.90 0.008 80)` | `#E5E2DA` |

Derived tokens (used for grids, dividers, hairlines):
```css
--grid:     color-mix(in oklab, var(--ink) 6%, transparent);
--hairline: color-mix(in oklab, var(--ink) 12%, transparent);
```

#### Color usage rule (60 / 30 / 10)
- **Ink — 60%** — primary surface or text foundation
- **Paper — 30%** — secondary surface
- **Orange — 10%** — reserved for things that move the race: CTAs, accents,
  live state, peaks, alerts, PRs. Do **not** use orange decoratively.

### Typography

Two families, loaded from Google Fonts:

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet" />
```

#### Inter — primary typeface (all human copy)
- Weights in use: 400 / 500 / 600 / 700 / 800
- Tracking: **−2%** at display sizes, **0%** at body
- Use for: all UI, copy, headlines

| Style | Size | Weight | Letter-spacing | Line-height |
|---|---|---|---|---|
| `display-1` | 88px (96px on cover) | 800 | −0.035em | 1 / 0.95 |
| `display-2` | 56px | 700 | −0.025em | 1.05 |
| `heading` | 32–40px | 600–700 | −0.015em to −0.02em | 1.1 |
| `subheading` | 22px | 500 | −0.01em | 1.3 |
| `body` | 17px | 400 | 0 | 1.55 |
| `small` | 13px | 500 | 0 | 1.4 |
| `lede` | 22px | 400 | 0 | 1.45 |

#### JetBrains Mono — data typeface
- Weights in use: 400 / 500 / 700
- Tracking: **+18%** (`0.18em`) for labels; near-zero for numerals
- Use for: numerals (splits, paces, HR, watts), labels, code, timestamps,
  tags, eyebrows

| Style | Size | Weight | Letter-spacing | Transform |
|---|---|---|---|---|
| `mono-num` | 28px (or 18px for code) | 500 | −0.01em | none |
| `mono-lbl` | 12px | 500 | 0.22em | UPPERCASE |
| eyebrow | 10–11px | 500 | 0.18–0.22em | UPPERCASE |

### Spacing & layout
- Page max-width: **1240px**
- Page padding: **64px 56px** top/sides on desktop
- Section vertical rhythm: **96px** between sections
- Border radius: **4px** (used everywhere — tiles, swatches, panels, buttons)
- Hairline borders: `1px solid var(--hairline)` (12% ink)

### Borders, dividers, shadows
- No drop shadows in the system. Surfaces are separated by **1px hairlines**
  and color contrast only.
- Dividers use `--hairline` (12% ink mixed with transparent).

---

## Logo / wordmark

The logo is a **wordmark only** — no symbol. Set in **Inter**:

- `AID` — weight **800** (extrabold)
- `STATION` — weight **400** (regular)
- All caps. Letter-spacing **0.04em** (tight, not loose).
- Baseline-aligned, no space between the two segments.

The split echoes the transition — run to bike, effort to recovery, data to
decision.

### Approved treatments
1. **Default** — light wordmark on `--ink` background
2. **Reverse** — dark wordmark on `--paper` background
3. **Accent** — `AID` in `--orange`, `STATION` in current foreground color
4. **Accent reverse** — full wordmark in `--orange` on light, with `STATION`
   optionally in `--ink`

### Sizes
- 18px — minimum (footer)
- 28px — UI / nav
- 56–96px — display

### Don'ts
- Don't add a tagline lockup
- Don't change the weight relationship (always 800 / 400)
- Don't introduce a symbol or icon mark
- Don't use orange for `STATION` while `AID` is in ink

### React snippet
```jsx
function Wordmark({ size = 28, accent = false, className }) {
  return (
    <span
      className={className}
      style={{
        fontFamily: 'Inter, system-ui, sans-serif',
        fontSize: size,
        letterSpacing: '0.04em',
        lineHeight: 1,
        display: 'inline-flex',
        alignItems: 'baseline',
      }}
    >
      <span style={{ fontWeight: 800, color: accent ? 'var(--orange)' : 'inherit' }}>AID</span>
      <span style={{ fontWeight: 400 }}>STATION</span>
    </span>
  );
}
```

---

## Voice & tone

### Sounds like
- "Your TSB is at −18. Tomorrow's long ride moves to Saturday — Friday is recovery."
- "HR drift held under 5% on the 90-min Z2. That's Ironman pace."
- "You under-fueled the brick by ~400 kcal. Tighten this before race week."
- "Three weeks out. The work is done. Sleep is the session now."

### Never sounds like
- Hype / emoji walls ("CRUSH YOUR GOALS 💪🔥")
- Marketing-speak ("synergize your performance metrics")
- Saccharine ("You did amazing sweetie")
- Hashtag energy ("NEW PR INCOMING 🔥🔥🔥")

### Copy rules
- Use real numbers wherever possible (BPM, watts, paces, TSB, CTL).
- Short, declarative sentences. Periods, not exclamation marks.
- Proper noun: render as `<strong>AID</strong>STATION` in body copy when the
  brand is mentioned inline (extrabold AID, regular STATION).
- No emoji in product copy. Iconography only when functional.

---

## Component patterns observed in the guide

### Topbar (page chrome)
```
| ● AIDSTATION · Brand System v0.1            APRIL 2026 · INTERNAL |
```
- 1px hairline border, 4px radius
- 14px / 24px padding
- Mono, 11px, `letter-spacing: 0.18em`, uppercase, `--ink-3` text
- 8px orange dot before the wordmark

### Section header
- Eyebrow: mono `01 / Logo` style — 12px, 0.22em tracking, `--ink-3`
- Title: 40px Inter 700, `−0.02em`
- Right-aligned subtitle: 14px `--ink-3`, max-width ~360px
- Bottom 1px hairline divider, 16px padding-bottom

### Meta strip (key/value row)
- Grid of 4 columns, top + bottom hairlines, 1px column dividers
- `dt`: mono 10px / 0.22em / uppercase / `--ink-3`
- `dd`: 16px Inter 500

### Phone mock (product preview)
- Body: `--ink-2`, radius 28px, padding 18px/14px
- Stat tile: `color-mix(in oklab, var(--paper) 6%, transparent)`, radius 6px
- Highlighted (live) stat: `--orange` background, `--ink` text
- Numbers: Inter 700, 22px, `−0.02em`. Small unit suffix at 11px / 400 / 0.6 opacity
- Section labels above numbers: mono 9px, 0.18em tracking, uppercase, 50% opacity

### Buttons / CTAs
- Default: `--ink` background, `--paper` text
- Hover/pressed: `--orange-deep` background, `--paper` text
- Primary (call-to-action): `--orange` background, `--ink` text
- Radius 4px, 14px vertical padding, mono uppercase label OR Inter 600 sentence-case

---

## Design tokens — drop-in CSS

```css
:root {
  /* Brand */
  --orange:       oklch(0.72 0.18 55);
  --orange-deep:  oklch(0.62 0.18 50);
  --orange-soft:  oklch(0.86 0.10 60);

  /* Ink (dark surfaces & text) */
  --ink:    oklch(0.16 0.005 250);
  --ink-2:  oklch(0.22 0.005 250);
  --ink-3:  oklch(0.32 0.008 250);

  /* Paper (light surfaces) */
  --paper:   oklch(0.98 0.005 80);
  --paper-2: oklch(0.95 0.006 80);
  --paper-3: oklch(0.90 0.008 80);

  /* Lines */
  --grid:     color-mix(in oklab, var(--ink) 6%, transparent);
  --hairline: color-mix(in oklab, var(--ink) 12%, transparent);

  /* Type */
  --font-sans: 'Inter', system-ui, -apple-system, sans-serif;
  --font-mono: 'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace;

  /* Radius */
  --radius: 4px;
  --radius-lg: 6px;
  --radius-phone: 28px;
}

html, body {
  background: var(--paper);
  color: var(--ink);
  font-family: var(--font-sans);
  -webkit-font-smoothing: antialiased;
}
```

### Utility classes (optional starting point)
```css
.mono       { font-family: var(--font-mono); }
.eyebrow    { font-family: var(--font-mono); font-size: 11px; letter-spacing: 0.22em; text-transform: uppercase; color: var(--ink-3); }
.hairline   { border: 1px solid var(--hairline); }

.display-1  { font-size: 88px; font-weight: 800; letter-spacing: -0.035em; line-height: 1; }
.display-2  { font-size: 56px; font-weight: 700; letter-spacing: -0.025em; line-height: 1.05; }
.heading    { font-size: 32px; font-weight: 600; letter-spacing: -0.015em; }
.subheading { font-size: 22px; font-weight: 500; letter-spacing: -0.01em; }
.body       { font-size: 17px; font-weight: 400; line-height: 1.55; }
.small      { font-size: 13px; font-weight: 500; color: var(--ink-3); }
```

---

## Implementation checklist for the `exercise` repo

1. **Add the Google Fonts link** to the document head (Inter + JetBrains Mono with the weights listed above).
2. **Add the `:root` token block** above to the global stylesheet — replacing or supplementing whatever color/type variables already exist. Map any pre-existing semantic tokens (`--bg`, `--fg`, `--accent`, etc.) to these.
3. **Replace any existing logo/wordmark** with the AIDSTATION wordmark component (see React snippet above; adapt to whatever framework is in use).
4. **Audit existing components** for orange usage — orange is reserved (CTAs, live state, alerts, PRs only). Anything currently using orange decoratively should move to ink/paper/slate.
5. **Numerals**: anywhere the app shows numeric data (paces, HR, watts, durations, splits, percentages) — switch the font to `var(--font-mono)`. This is the single biggest visual signature of the brand.
6. **Radius pass**: standardize component radii to 4px (6px for inner stat tiles, 28px for phone-frame mocks if any).
7. **Voice pass**: review existing copy against the "sounds like / never sounds like" lists. Strip emoji, exclamation marks, and marketing language from product strings.

---

## Files in this bundle
- `README.md` — this file (read first)
- `AidStation Brand Guide.html` — full visual reference of the brand system

## Assets
No raster or vector assets are needed. The wordmark is set live in CSS. The
"AS" app-icon glyph in the brand guide is also CSS-typeset. If a static logo
file is required for favicons or social cards, render the wordmark to SVG
using Inter 800/400 with the values listed above.
